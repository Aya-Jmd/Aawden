"""Explicit allowlist packaging, without any network publication."""
import zipfile
from pathlib import Path
from .artifacts import file_hash, read_json, verify_run


def package_submission(run: Path, output: Path):
    verify_run(run)
    root = Path(__file__).resolve().parents[2]
    output.parent.mkdir(parents=True, exist_ok=True)
    sources = []
    for folder in ("src", "configs", "tests", "scripts", "datasets", "docs", "notebooks", "fixtures"):
        directory = root / folder
        if directory.is_dir():
            sources.extend(p for p in directory.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix not in {".pyc", ".tmp"})
    for name in ("README.md", "EXPLANATION.MD", "LICENSE", "THIRD_PARTY_NOTICES.md", "pyproject.toml",
                 "requirements-core.lock", "requirements-research.in", "requirements-research.lock",
                 "dependency-sources.lock.json", "aawden.py", "START_AAWDEN.ps1", ".gitignore"):
        if (root / name).is_file():
            sources.append(root / name)
    summary = read_json(run / "summary.json")
    note = ("Aawden local submission draft. Evidence kind: " + summary["evidence_kind"] + ".\n"
            "A constructed toy run does not establish a Cohere improvement or complete competition requirements.\n"
            "Supply actual Cohere measurements, evaluator-separated final data, required public Hugging Face artifacts, "
            "and a write-up before submitting. This bundle has not been uploaded or submitted.\n")
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("SUBMISSION_STATUS.txt", note)
        for path in sorted(set(sources)):
            archive.write(path, str(path.relative_to(root)))
        for path in run.rglob("*"):
            if path.is_file() and path.suffix in (".json", ".md") and "__pycache__" not in path.parts and ".audit-cache" not in path.parts:
                archive.write(path, "evidence/" + str(path.relative_to(run)))
    return {"bundle": str(output.resolve()), "sha256": file_hash(output), "evidence_kind": summary["evidence_kind"],
            "uploaded": False, "submission_ready": False}

