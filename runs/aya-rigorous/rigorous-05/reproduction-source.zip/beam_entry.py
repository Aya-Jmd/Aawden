import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory

from beam import Image, Volume, Output, env, function

SOURCE = Path(__file__).resolve().parent
JOB = json.loads((SOURCE / "beam-job.json").read_text(encoding="utf-8"))
MOUNT = Path("/mnt/aawden")

if not env.is_remote():
    import grpc
    from beta9.abstractions.base import set_channel
    from beta9.channel import AuthTokenInterceptor
    from beta9.config import ConfigContext

    token = os.environ["BEAM_TOKEN"]
    context = ConfigContext(token=token, gateway_host="gateway.beam.cloud", gateway_port=443,
                            api_url="https://app.beam.cloud")
    roots = Path(os.environ["AAWDEN_BEAM_TLS"]).read_bytes()
    address = "gateway.beam.cloud:443"
    transport = grpc.secure_channel(address, grpc.ssl_channel_credentials(root_certificates=roots), options=[
        ("grpc.max_receive_message_length", 16 * 1024**2), ("grpc.max_send_message_length", 16 * 1024**2),
    ])
    grpc.channel_ready_future(transport).result(timeout=20)
    channel = grpc.intercept_channel(transport, AuthTokenInterceptor(token))
    channel.config = context
    channel.cache_key = hashlib.sha256(f"{address}\n{token}".encode()).hexdigest()
    set_channel(channel=channel)


@function(
    name=JOB["name"], pool=JOB.get("pool"), gpu=JOB["gpu"], gpu_count=1, cpu=JOB["cpu"], memory=JOB["memory"],
    image=Image(python_version="python3.11", python_packages=["uv==0.13.3"]).add_commands([
        "command -v git >/dev/null || (apt-get update -qq && apt-get install -y --no-install-recommends git)",
    ]),
    timeout=JOB["timeout"], retries=0, headless=False,
    volumes=[Volume(name=JOB["volume"], mount_path=str(MOUNT))], secrets=[JOB["secret"]],
)
def aya_pilot():
    output = MOUNT / JOB["output"]
    output.mkdir(parents=True, exist_ok=True)
    access_token = os.environ[JOB["secret"]]
    install_env = {k: v for k, v in os.environ.items() if k not in {JOB["secret"], "BEAM_TOKEN", "HF_TOKEN"}}
    install_env.update(UV_CACHE_DIR=str(MOUNT / "uv-cache"), UV_LINK_MODE="copy", PYTHONUNBUFFERED="1")
    model_env = dict(install_env, HF_HOME=str(MOUNT / "hf-cache"), HF_TOKEN=access_token,
                     HF_HUB_DISABLE_PROGRESS_BARS="1", HF_HUB_DOWNLOAD_TIMEOUT="90")
    model_env.pop("HF_DEBUG", None)
    result = {"exit_code": 1, "stage": "environment"}
    artifact = MOUNT / f"{JOB['output']}-evidence.zip"
    gpu = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"],
                         env=install_env, capture_output=True, text=True, timeout=20)
    (output / "gpu.txt").write_text(gpu.stdout + gpu.stderr, encoding="utf-8")
    print("GPU:", gpu.stdout.strip(), flush=True)
    try:
        with TemporaryDirectory(prefix="aawden-venv-") as work:
            venv = Path(work) / "research"
            python = venv / "bin/python"
            print("Installing pinned research environment", flush=True)
            subprocess.run([sys.executable, "-m", "uv", "venv", str(venv), "--python", sys.executable],
                           cwd=SOURCE, env=install_env, check=True)
            subprocess.run([sys.executable, "-m", "uv", "pip", "sync", "--python", str(python),
                            "--torch-backend", JOB.get("torch_backend", "cu126"), "requirements-research.lock"],
                           cwd=SOURCE, env=install_env, check=True)
            command = [str(python), "-u", "scripts/run_aya_pilot.py", "--output", str(output)]
            if JOB.get("sequential_gpu"):
                command += ["--sequential-gpu"]
            result["stage"] = "preflight"
            if JOB.get("rigorous_review"):
                ready = gpu.returncode == 0
                command = [str(python), "-u", "scripts/evaluate_rigorous_review.py",
                           "--output", str(output / "study"), "--protocol", JOB["protocol"],
                           "--model-config", JOB["model_config"]]
            else:
                preflight = subprocess.run(command + ["--preflight-only"], cwd=SOURCE, env=model_env)
                result["exit_code"] = preflight.returncode
                ready = not preflight.returncode
            if JOB.get("baseline_only"):
                report = json.loads((output / "preflight.json").read_text(encoding="utf-8"))
                gpu_check = report["gpu"]
                ready = (report["runtime"]["passed"] and report["model_access"]["passed"]
                         and report["toolkits"]["AuditKIT"]["passed"] and gpu_check.get("native_bf16")
                         and gpu_check.get("free_gib", 0) >= 19 and shutil.disk_usage(output).free >= 25 * 1024**3)
                command = [str(python), "-u", "aawden.py", "baseline", "--output", str(output / "baseline")]
            else:
                if JOB.get("neutral_study"):
                    command = ([str(python), "-u", "aawden.py", "mental-review", "--checkpoint", str(SOURCE / "initial-adapter.safetensors"),
                                "--previous", str(SOURCE / "previous-mental-baseline"), "--output", str(output / "study")]
                               if JOB.get("mental_review") else
                               [str(python), "-u", "aawden.py", "adapter-review", "--checkpoint", str(SOURCE / "initial-adapter.safetensors"),
                                "--previous", str(SOURCE / "previous-baseline"), "--output", str(output / "study")]
                               if JOB.get("review_prompts") else
                               [str(python), "-u", "scripts/train_aya_adapter.py", "--output", str(output / "study")]
                               if JOB.get("train_adapter") else
                               [str(python), "-u", "aawden.py", "neutral-study", "--output", str(output / "study")])
                    if JOB.get("resume_adapter"):
                        command += ["--resume-checkpoint", str(SOURCE / "initial-adapter.safetensors")]
                    if JOB.get("refine_adapter"):
                        command += ["--refine"]
                elif JOB.get("parity_only"):
                    command = [str(python), "-u", "aawden.py", "parity", "--sequential", "--output", str(output / "parity.json")]
                elif JOB.get("sequential_gpu"):
                    command += ["--reuse-baseline", str(SOURCE / "baseline-evidence")]
            if ready:
                result["stage"] = ("rigorous_review" if JOB.get("rigorous_review") else
                                   "original_model_baseline" if JOB.get("baseline_only") else
                                   "neutral_study" if JOB.get("neutral_study") else
                                   "sequential_parity" if JOB.get("parity_only") else "pilot")
                with subprocess.Popen(command, cwd=SOURCE, env=model_env) as pilot:
                    saved_checkpoints = set()
                    while True:
                        try:
                            result["exit_code"] = pilot.wait(timeout=45)
                            break
                        except subprocess.TimeoutExpired:
                            if JOB.get("neutral_study") or JOB.get("rigorous_review"):
                                for checkpoint in sorted((output / "study").glob("adapter-epoch-*.safetensors")):
                                    if checkpoint.name not in saved_checkpoints:
                                        Output(path=checkpoint).save()
                                        saved_checkpoints.add(checkpoint.name)
                                print("Neutral study answers saved:", {stage: sum(1 for _ in (output / "study" / stage / "predictions").glob("*.json"))
                                                                       for stage in ("development", "development_refined",
                                                                                     "confirmation")}, flush=True)
                                continue
                            predictions = output / "baseline" / "predictions"
                            count = sum(1 for _ in predictions.glob("*.json"))
                            log = output / "pilot.json"
                            stages = json.loads(log.read_text(encoding="utf-8")).get("stages", {}) if log.exists() else {}
                            print("Pilot progress:", {k: v["status"] for k, v in stages.items()},
                                  "baseline answers saved:", count, flush=True)
    except (OSError, subprocess.CalledProcessError) as error:
        result.update(exit_code=1, error=type(error).__name__)
        print("Pilot stopped during", result["stage"], "with", type(error).__name__, flush=True)
    for logfile in sorted(output.glob("*.log")):
        if result["exit_code"]:
            with logfile.open("rb") as stream:
                stream.seek(max(0, logfile.stat().st_size - 4500))
                print(logfile.name, stream.read().decode("utf-8", "replace").replace(access_token, "[redacted]"), flush=True)
    (output / "beam-result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(artifact, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(output.rglob("*")):
            relative = path.relative_to(output)
            if (path.is_file() and path.suffix in (".json", ".md", ".log", ".txt")
                    and not any(part.startswith(".") for part in relative.parts)):
                archive.write(path, relative.as_posix())
        archive.write(SOURCE / "requirements-research.lock", "requirements-research.lock")
    print("Saved private evidence archive", flush=True)
    Output(path=artifact).save()
    for checkpoint in output.rglob("adapter.safetensors"):
        Output(path=checkpoint).save()
    return dict(result, evidence=artifact.read_bytes() if artifact.stat().st_size <= 6 * 1024**2 else None)


if __name__ == "__main__":
    result = aya_pilot.remote()
    if not isinstance(result, dict):
        raise RuntimeError("Beam returned no pilot result")
    evidence = result.pop("evidence")
    if evidence:
        destination = Path(os.environ["AAWDEN_LOCAL_EVIDENCE"])
        staging = destination.with_suffix(".tmp")
        staging.write_bytes(evidence)
        staging.replace(destination)
    print("Pilot result:", result, flush=True)
    raise SystemExit(result["exit_code"])
