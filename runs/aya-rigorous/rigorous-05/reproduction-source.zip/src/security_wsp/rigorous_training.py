"""Bounded continuation training on exposed examples and concrete code explanations."""
import json
import random

from .artifacts import atomic_json, file_hash
from .data import CLEAN
from .rigorous_review import checked_dataset, rigorous_request


# These are supervised targets for the exposed first confirmation set only.
DETAILS = {
    "trusted_alias": ("The reassigned fragment inserts the name before execute.",
                      "The alias is fixed and the name remains a separate bound value."),
    "conditional_normalization": ("A name containing a quote takes the raw interpolation branch.",
                                   "Alphabetic names cannot close the literal and other names are bound."),
    "dictionary_override": ("A quote triggers the override of the bound query with raw SQL text.",
                            "The override preserves the query placeholder and binds the name."),
    "sort_after_interpolation": ("The raw format operation embeds the name before the order clause is appended.",
                                 "The name stays bound while the fixed order column is appended."),
    "commented_decoy": ("A quote sets index one and executes the raw fallback query.",
                        "The index is fixed at zero so the interpolated fallback is never executed."),
    "escape_then_recover": ("The second replacement undoes quote doubling before building SQL.",
                            "The literal passed into SQLite preserves the doubled quote characters."),
    "named_parameter_and_clause": ("The OR arm interpolates the name even though the other arm binds it.",
                                   "The only use of the name is the named bind argument."),
    "keyed_callable": ("A name containing a quote selects the callable that interpolates it.",
                       "Both modes call the function that binds the name."),
    "tuple_match_guard": ("A same tenant nonowner matches the second alternative and receives the record.",
                          "Only the pattern with a true owner comparison can return the record."),
    "approval_reset": ("The later OR allows a same tenant member even when the owner check failed.",
                       "The later AND retains the owner check for the member path."),
    "early_cache_hit": ("The early cache hit returns the requested record to any authenticated session.",
                        "Both the cache hit and the fallback require the owner check."),
    "negated_denials": ("The all check fails to block an authenticated nonowner.",
                        "A true owner mismatch alone makes any return true and blocks the request."),
    "filter_projection": ("An empty owner-filtered list falls back to the original unfiltered row.",
                          "Only the owner-filtered list can contribute a returned record."),
    "delegated_decision": ("The member OR branch bypasses the owner comparison.",
                          "The delegated decision compares the requested item owner to the session ID."),
    "fallback_principal": ("The assignment overwrites the session principal with the requested record owner.",
                           "The preexisting session ID survives setdefault and the later assignment."),
    "request_key_guard": ("The check uses an owned key but the returned row uses the requested key.",
                          "The same requested key determines both permission and the returned row."),
}


def target(case, evidence_first):
    name = case.family_id.removeprefix(f"rigorous_confirmation_{case.target_category}_")
    safe = case.oracle_verdict == CLEAN
    if name in DETAILS:
        explanation = DETAILS[name][safe]
    elif case.target_category == "sql_injection":
        explanation = ("The lookup keeps the name literal." if safe else
                       "The lookup can execute SQL syntax originating in the untrusted name.")
    else:
        explanation = ("The requested row is returned only to an actor allowed by the stated policy." if safe else
                       "The code can return the requested row without enforcing the stated access policy.")
    fields = {"category": case.target_category, "explanation": explanation,
              "evidence_lines": list(range(2, len(case.code.splitlines()) + 1)),
              "verdict": case.oracle_verdict, "confidence": .9}
    if evidence_first:
        return json.dumps(fields, separators=(",", ":"))
    verdict = fields.pop("verdict")
    return json.dumps({"verdict": verdict, **fields}, separators=(",", ":"))


def refine(adapter, root, spec, forbidden, output):
    import torch
    from safetensors.torch import save_file
    from .adaptation import LowRankLinear

    cases = checked_dataset(root, spec["exposed"]) + checked_dataset(root, spec["replay"])
    if {case.family_id for case in cases} & {case.family_id for case in forbidden}:
        raise ValueError("Training families overlap with validation or confirmation")
    model = adapter.model
    parameters = {f"{name}.{part}": getattr(module, part) for name, module in model.named_modules()
                  if isinstance(module, LowRankLinear) for part in ("a", "b")}
    if not parameters:
        raise ValueError("Expected a verified LoRA starting point")
    for parameter in parameters.values():
        parameter.requires_grad_(True)
    examples = []
    for case in cases:
        for variant in spec["training_variants"]:
            request = rigorous_request(case, variant)
            prefill = request.messages[-1]["role"] == "assistant"
            messages = request.messages[:-1] if prefill else request.messages
            prefix = adapter.chat_prefix(messages)
            if prefill:
                prefix += request.messages[-1]["content"]
            answer = target(case, prefill)
            forced = request.messages[-1]["content"] if prefill else ""
            if not answer.startswith(forced):
                raise ValueError("Training answer differs from the prescribed response prefix")
            prefix_tokens = adapter._tokens(prefix).cpu()
            tokens = adapter._tokens(prefix + answer[len(forced):] + adapter.tokenizer.eos_token).cpu()
            boundary = (tokens[:, :prefix_tokens.shape[1]] != prefix_tokens).nonzero()
            start = boundary[0, 1].item() if len(boundary) else prefix_tokens.shape[1]
            labels = tokens.clone()
            labels[:, :start] = -100
            examples.append((tokens, labels))

    randomizer = random.Random(spec["seed"])
    torch.manual_seed(spec["seed"])
    optimizer = torch.optim.AdamW(list(parameters.values()), lr=spec["learning_rate"], weight_decay=0)
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model.enable_input_require_grads()
    model.train()
    history = []
    print("Refining Aya with", len(examples), "labelled review examples per epoch", flush=True)
    try:
        for epoch in range(spec["epochs"]):
            randomizer.shuffle(examples)
            losses = []
            for tokens, labels in examples:
                optimizer.zero_grad(set_to_none=True)
                result = model(input_ids=tokens.to(adapter.device), labels=labels.to(adapter.device), use_cache=False)
                result.loss.backward()
                torch.nn.utils.clip_grad_norm_(list(parameters.values()), 1.0)
                optimizer.step()
                losses.append(result.loss.detach().item())
            history.append({"epoch": epoch + 1, "mean_loss": sum(losses) / len(losses)})
            print("Refinement", history[-1], flush=True)
    finally:
        model.gradient_checkpointing_disable()
        model.disable_input_require_grads()
        model.eval()
        for parameter in parameters.values():
            parameter.requires_grad_(False)
    checkpoint = output / "adapter.safetensors"
    parent = adapter.metadata["adapter_sha256"]
    save_file({name: tensor.detach().cpu().contiguous() for name, tensor in parameters.items()}, checkpoint)
    trained = file_hash(checkpoint)
    if trained == parent:
        raise RuntimeError("The training run did not change the adapter")
    adapter.metadata.update(adapter_sha256=trained, parent_adapter_sha256=parent)
    atomic_json(output / "training.json", {"protocol": spec, "parent_adapter_sha256": parent,
                                            "adapter_sha256": trained, "history": history,
                                            "training_case_count": len(cases)})
    return cases
